import 'package:flutter/material.dart';


//const Color mainBlue = const Color.fromRGBO(77, 123, 243, 1.0);
const Color mainBlue = const Color.fromRGBO(7, 123, 243, 1.0);
